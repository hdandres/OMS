<?php
// src/Tipddy/OmsBundle/Entity/Cliente.php

namespace Tipddy\OMSBundle\Entity;

use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
*
* @ORM\Table(name="cliente")
* @ORM\Entity
*/
class Cliente
{
    /**
     * @var bigint $id
     *
     * @ORM\Column(name="id", type="bigint", nullable=false)
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="IDENTITY")
    */
     private $id;
      
    /**
     * @ORM\Column(name="nombre", type="string", length=255, nullable=false)
     *
     * @Assert\NotBlank()
    */
     private $nombre;
      
    /**
     * @ORM\Column(name="apellido", type="string", length=255, nullable=false)
     *
     * @Assert\NotBlank()
    */
     private $apellido;
      
    /**
     * @ORM\Column(name="descripcion", type="string", length=255, nullable=false)
     *
     * @Assert\NotBlank()
    */
     private $descripcion;
   
    /**
     * @ORM\Column(name="razon_social", type="string", length=255, nullable=false)
     *
     * @Assert\NotBlank()
    */
     private $razonSocial;
      
    /**
     * @ORM\Column(name="tipo", type="char", length=2, nullable=false)
     *
     * @Assert\NotBlank()
    */
     private $tipo;
     
    /**
     * @ORM\Column(name="fecha_fundacion", type="date", nullable=false)
     *
     * @Assert\Date
    */
     private $fechaFundacion;
   
    /**
     * @ORM\Column(name="direccion", type="string", length=255, nullable=false)
     *
     * @Assert\NotBlank()
    */
     private $direccion;
           
    /**
     * 
     * @ORM\ManyToOne(targetEntity="Region")
     * @ORM\JoinColumns({
     * @ORM\JoinColumn(name="region_id", referencedColumnName="id")
     * })
    */
    private $regionId;
  
    /**
     * 
     * @ORM\ManyToOne(targetEntity="Comuna")
     * @ORM\JoinColumns({
     * @ORM\JoinColumn(name="comuna_id", referencedColumnName="id")
     * })
    */    
    private $comunaId;
      
    /**
     * @ORM\Column(name="fono_fijo", type="string", length=255, nullable=true)
     *
    */
     private $fonoFijo;
           
    /**
     * @ORM\Column(name="fono_movil", type="string", length=255, nullable=true)
     *
    */
     private $fonoMovil;
   
    /**
     * @ORM\Column(name="email", type="string", length=100, nullable=false)
     *
     * @Assert\NotBlank()
    */
     private $email;
      
    /**
     * @ORM\Column(name="sucursal", type="char", length=2, nullable=false)   
     *
     * @Assert\NotBlank()
    */
     private $sucursal;
          
    /**
     * @ORM\Column(name="nombre_encargado", type="string", length=255, nullable=true)
     *
    */
     private $nombreEncargado;
     
    /**
     * @ORM\Column(name="nombre_comercial", type="string", length=255, nullable=true)
     *
    */
     private $nombreComercial;
     
    /**
     * @ORM\Column(name="repre_legal", type="string", length=255, nullable=true)
     *
    */
     private $repreLegal;
   
    /**
     * @ORM\Column(name="repre_rut", type="string", length=255, nullable=true)
     *
    */
     private $repreRut;
     
    /**
     * @ORM\Column(name="repre_nombre", type="string", length=255, nullable=true)
     *
    */
     private $repreNombre;
      
    /**
     * @ORM\Column(name="repre_fono", type="string", length=255, nullable=true)
     *
    */
     private $repreFono;
      
    /**
     * @ORM\Column(name="repre_direccion", type="string", length=255, nullable=true)
     *
    */
     private $repreDireccion;
     
    /**
     * @ORM\ManyToOne(targetEntity="Region")
     * @ORM\JoinColumns({
     * @ORM\JoinColumn(name="repre_region", referencedColumnName="id")
     * })
    */      
     private $repreRegion;
   
    /**
     * 
     * @ORM\ManyToOne(targetEntity="Comuna")
     * @ORM\JoinColumns({
     * @ORM\JoinColumn(name="repre_comuna", referencedColumnName="id")
     * })
    */
     private $repreComuna;
           
}

